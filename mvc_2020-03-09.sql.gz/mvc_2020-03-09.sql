﻿# ************************************************************
# Sequel Pro SQL dump
# Version 5446
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 8.0.17)
# Database: mvc
# Generation Time: 2020-03-09 11:01:14 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table tasks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tasks`;

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` tinytext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `author` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `email` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `status` int(1) DEFAULT NULL,
  `is_edit_description` int(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;

INSERT INTO `tasks` (`id`, `title`, `description`, `author`, `email`, `status`, `is_edit_description`, `created_at`)
VALUES
	(51,'Задача № 1',' Как быстро посчитать сумму всех чисел от 1 до 100?\r\n\r\nОтвет: (100/2 + 1) * 100 = 5050','user 2','admin2@mail.com',1,1,'2020-03-09 11:46:39'),
	(52,'Задача № 2',' Какой знак надо поставить между написанными рядом цифрами 2 и 3, чтобы получилось число, большее двух, но меньшее трёх??\r\n','user 1','admin@mail.com',1,1,'2020-03-09 12:19:36'),
	(53,'Задача № 3',' Запишите ноль тремя пятёрками, используя для этого только знаки арифметических действий и скобки.\r\n','user 2',NULL,1,NULL,'2020-03-08 22:15:05'),
	(54,'Задача № 4',' Разделить циферблат часов двумя прямыми линиями на три части так, чтобы, сложив числа, в каждой части получить одинаковые суммы.\r\n','user 2',NULL,NULL,NULL,'2020-03-08 22:14:11'),
	(55,'Задача № 5',' В автобусе вам попался билет с номером 524127. Попробуйте, не меняя порядка цифр, расставить между ними знаки арифметических действий так, чтобы в итоге получилось 100.\r\n','user 4','222@333.com',1,NULL,'2020-03-08 22:15:28'),
	(56,'Задача № 6',' С какой средней скоростью автомашина проехала путь из одного города в другой, если одну половину пути она ехала со скоростью 40 км/ч, а вторую — со скоростью 60 км/ч?\r\n','user 1','444@555.com',NULL,NULL,'2020-03-08 22:15:42'),
	(57,'Задача № 7',' Два путешественника идут по одной и той же дороге в одном и том же направлении. Первый находится на 8 км впереди другого и идёт со скоростью 4 км/ч, второй делает по 6 км в час. У одного из путешественников есть собака, которая именно в тот момент, когда мы начали наблюдать за ними, побежала от своего хозяина к другому путешественнику (её скорость 15 км/ч). Затем она вернулась к хозяину и опять побежала к другому путешественнику. Так она бегала от одного к другому до тех пор, пока путешественники не встретились. Какой путь пробежала собака?\r\n','user 6',NULL,1,NULL,'2020-03-08 22:15:06'),
	(58,'Задача № 8','Два пассажирских поезда, оба длиной по 250 м, идут навстречу друг другу с одинаковой скоростью 45 км/час. Сколько секунд пройдёт после того, как встретились машинисты, до того, как встретятся кондукторы последних вагонов?\r\n','Admin','admin@mail.com',1,1,'2020-03-08 00:20:01'),
	(63,'Test','это из БД с id 63','user 7','3@3.com',1,1,'2020-03-09 11:47:35');

/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `email` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `login`, `password`, `email`, `created_at`)
VALUES
	(1,'Admin','123','admin@mail.com','2020-03-04 00:55:36');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
